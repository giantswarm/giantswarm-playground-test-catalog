{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "labels.common" -}}
app: {{ include "name" . | quote }}
{{ include "labels.selector" . }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
application.giantswarm.io/team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
helm.sh/chart: {{ include "chart" . | quote }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "labels.selector" -}}
app.kubernetes.io/name: {{ include "name" . | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
{{- end -}}
{{/*
Proxy env on every Deployment's "manager" container, for controllers that reach
the on-prem provider and the workload cluster through .Values.proxy.
*/}}
{{- define "proxy.postRenderers" -}}
{{- if .Values.proxy.https -}}
postRenderers:
  - kustomize:
      patches:
        - target:
            kind: Deployment
          patch: |
            apiVersion: apps/v1
            kind: Deployment
            metadata:
              name: any
            spec:
              template:
                spec:
                  containers:
                    - name: manager
                      env:
                        {{- range $k, $v := dict "HTTP_PROXY" .Values.proxy.http "HTTPS_PROXY" .Values.proxy.https "NO_PROXY" .Values.proxy.noProxy }}
                        - name: {{ $k }}
                          value: {{ $v | quote }}
                        - name: {{ lower $k }}
                          value: {{ $v | quote }}
                        {{- end }}
{{- end }}
{{- end -}}
